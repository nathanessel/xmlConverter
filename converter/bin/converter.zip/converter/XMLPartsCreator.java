package converter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

public class XMLPartsCreator {
    protected DocumentBuilderFactory domFactory = null;
    protected DocumentBuilder domBuilder = null;

    Map<String, Part> partsMap = new HashMap<String,Part>();
    
    public XMLPartsCreator() {
        try {
            domFactory = DocumentBuilderFactory.newInstance();
            domBuilder = domFactory.newDocumentBuilder();
        } catch (FactoryConfigurationError exp) {
            System.err.println(exp.toString());
        } catch (ParserConfigurationException exp) {
            System.err.println(exp.toString());
        } catch (Exception exp) {
            System.err.println(exp.toString());
        }

    }

    public int convertFile(String txtFileName, String xmlFileName, char delimiter) 
    {
        int rowsCount = -1;
        try {
            Document newDoc = domBuilder.newDocument();
            // Root element
            Element partsElement = newDoc.createElement("Parts");
            newDoc.appendChild(partsElement);

            CSVParser parser = new CSVParserBuilder().withSeparator(delimiter).build();
        	
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(txtFileName), "utf-8"));
            
            CSVReader reader = new CSVReaderBuilder(br).withCSVParser(parser).build();

            List<String> partNumberList = new ArrayList<String>();
            
            String[] nextLine;
            int line = 0;
            List<String> headers = new ArrayList<String>();
            
            Part part = null;
            
            while ((nextLine = reader.readNext()) != null) 
            {
            	String masterPartNumber = "";
            	boolean partExists = false;

                if (line == 0) 
                { 
                    for (String col : nextLine) 
                    {
                        headers.add(col);
                    }
                } 
                
                else 
                { 
               		masterPartNumber = nextLine[2];
                	
                	part = partsMap.get(masterPartNumber);
                	
                	if (part == null)
                		part = new Part();
                	else
                		partExists = true;
                	
                    int col = 0;
                    for (String value : nextLine) 
                    {
                        String header = headers.get(col);

                        if (value.equalsIgnoreCase("Y"))
                        	value = "true";
                        else if (value.equalsIgnoreCase("N"))
                        	value = "false";
                        
                        if (col < 7 && !partExists)
                        	readCSVToPartData(part.partDataElement, header, value);
                        
                        else if (col == 7 && partExists)
                        	readCSVToPartData(part.customerElement, header, value);
                        
                        else if (col > 7 && col < 12 && !partExists)
                        	readCSVToPartData(part.partDataElement, header, value);
                        
                        else if (col >= 12 && col < 31 && !partExists)
                        	readCSVToPartData(part.componentHandlingElement, header, value);

                        else if (col >= 31 && col < 42 && !partExists)
                        	readCSVToPartData(part.partDataElement, header, value);
                        
                        else if (col >= 42 && col < 47)
                        	readCSVToNestedPartData(part.manufacturerPartElement, header, value, partExists, masterPartNumber);
                        
                        else if (col >= 47 && col < 51)
                        	readCSVToNestedPartData(part.vendorPartElement, header, value, partExists, masterPartNumber);

                        else if (col >= 51 && col < 55)
                        	readCSVToNestedPartData(part.customerElement, header, value, partExists, masterPartNumber);

                        else if (col >= 55 && col < 57)
                        	readCSVToNestedPartData(part.alternatePartElement, header, value, partExists, masterPartNumber);

                        else if (col >= 57 && col < 59)
                        	readCSVToNestedPartData(part.customFieldsElement, header, value, partExists, masterPartNumber);
                        
                        else if (col >= 59 && col < 69 && !partExists)
                        	readCSVToPartData(part.electronicPartElement, header, value);
                        	
                        else if (col >= 69 && col < 74)
                        	readCSVToNestedPartData(part.machineElement, header, value, partExists, masterPartNumber);
                        	
                        // System.out.println("col " + col);
                        col++;
                    }
                }
                System.out.println("line " + line);

                if (line != 0)
                {
                	if (!partExists)
                		partsMap.put(masterPartNumber, part);
                }
                
                line++;
            }
            
            
            
            for (Map.Entry<String, Part> entry : partsMap.entrySet()) {
                String key = entry.getKey();
                System.out.println("key " + key);
                
                Element partDataElement = newDoc.createElement("PartData");
                partsElement.appendChild(partDataElement);
                
                part = entry.getValue();
                
                		addToPartDataElement(newDoc, partDataElement, part.partDataElement);
                		addToPartDataElement(newDoc, partDataElement, part.customerElement, "Customer");
                		addToPartDataElement(newDoc, partDataElement, part.customerElement, "ComponentHandling");

                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.manufacturerPartElement, part, 
                				"ManufacturerParts", "ManufacturerPart"));
                		
                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.vendorPartElement, part, "VendorParts", "VendorPart"));
                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.customerPartElement, part, "CustomerParts", "CustomerPart"));
                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.alternatePartElement, part, "AlternateParts", "AlternatePart"));
                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.customFieldsElement, part, "CustomFields", "Entry"));
                		
                		addToPartDataElement(newDoc, partDataElement, part.electronicPartElement, "ElectronicPart");
                		
                		partDataElement.appendChild(addNestedPartDataElement(newDoc, partDataElement, part.machineElement, part, 
                				"MachineSpecificAttributes", "Machine"));
            }

            FileWriter writer = null;

            try {

                writer = new FileWriter(new File(xmlFileName));

                TransformerFactory tranFactory = TransformerFactory.newInstance();
                Transformer aTransformer = tranFactory.newTransformer();
                aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
                aTransformer.setOutputProperty(OutputKeys.METHOD, "xml");
                aTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

                Source src = new DOMSource(newDoc);
                Result result = new StreamResult(writer);
                aTransformer.transform(src, result);

                writer.flush();

            } catch (Exception exp) {
                exp.printStackTrace();
            } finally {
                try {
                    writer.close();
                } catch (Exception e) {
                }
            }

            // Output to console for testing
            // Result result = new StreamResult(System.out);

        } catch (IOException exp) {
            System.err.println(exp.toString());
        } catch (Exception exp) {
            System.err.println(exp.toString());
        }
        return rowsCount;
        // "XLM Document has been created" + rowsCount;
    }
    
    public Element addNestedPartDataElement(Document newDoc, Element partDataElement, List<PartElement> elementList, Part part, String parentTag, String childTag) {
    	Element parentElement = newDoc.createElement(parentTag);
		Element childElement = newDoc.createElement(childTag);

    	for (PartElement partElement : elementList)
    	{
        	Element currentElement = newDoc.createElement(partElement.getHeader());
        	currentElement.appendChild(newDoc.createTextNode(partElement.getValue().trim()));
        	
        	System.out.println("appending to child " + childTag + "\r\n");
        	System.out.println("header " + partElement.getHeader() + " value " + partElement.getValue() + "\r\n");
        	
        	childElement.appendChild(currentElement);
    	}
    	parentElement.appendChild(childElement);
    	System.out.println("appending to parent " + parentTag + "\r\n\r\n");

    	
    	return parentElement;
    }
    
    public void addToPartDataElement(Document newDoc, Element partDataElement, List<PartElement> elementList) {
    	for (PartElement partData : elementList)
    	{
            Element currentElement = newDoc.createElement(partData.getHeader());
            currentElement.appendChild(newDoc.createTextNode(partData.getValue().trim()));
            partDataElement.appendChild(currentElement);
    	}
    }
    
    public void addToPartDataElement(Document newDoc, Element partDataElement, List<PartElement> elementList, String tag) {
    	Element componentHandlingElement = newDoc.createElement(tag);
    	
    	for (PartElement componentHandling : elementList)
    	{
        	Element currentElement = newDoc.createElement(componentHandling.getHeader());
        	currentElement.appendChild(newDoc.createTextNode(componentHandling.getValue().trim()));
        	componentHandlingElement.appendChild(currentElement);
            partDataElement.appendChild(componentHandlingElement);
    	}
    }
    
    public void readCSVToPartData(List<PartElement> partElementList, String header, String value) {
		PartElement currentElement = new PartElement(header,value);
		partElementList.add(currentElement);
    }
    
    public void readCSVToNestedPartData(List<PartElement> partElementList, String header, String value, boolean partExists, String masterPartNumber) {
    	PartElement currentElement = new PartElement (header,value);
    	
    	if (partExists)
    		partElementList.add(currentElement);
    	else	
    		partElementList.add(currentElement);
    }
    
    

}