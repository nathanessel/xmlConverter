package converter;

import java.util.ArrayList;
import java.util.List;

public class Part {
	//private String item.item = "";
	
	String masterPartNumber = "";
	
	List<PartElement> componentHandlingElement = new ArrayList<PartElement>();
	List<PartElement> manufacturerPartElement = new ArrayList<PartElement>();
	List<PartElement> vendorPartsElement = new ArrayList<PartElement>();
	List<PartElement> vendorPartElement = new ArrayList<PartElement>();
	List<PartElement> customerPartElement = new ArrayList<PartElement>();
	List<PartElement> alternatePartElement = new ArrayList<PartElement>();
	List<PartElement> customFieldsElement = new ArrayList<PartElement>();
	List<PartElement> entryElement = new ArrayList<PartElement>();
	List<PartElement> electronicPartElement = new ArrayList<PartElement>();
	List<PartElement> machineElement = new ArrayList<PartElement>();
	List<PartElement> partDataElement = new ArrayList<PartElement>();
	List<PartElement> customerElement = new ArrayList<PartElement>();


}
